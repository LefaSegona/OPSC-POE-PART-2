package com.example.pocket_ninja.data.database.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "investments")
data class Investment(
    @PrimaryKey(autoGenerate = true) val investmentId: Long = 0,
    @ColumnInfo(name = "user_id") val userId: Long,
    @ColumnInfo(name = "amount") val amount: Double,
    @ColumnInfo(name = "plan_name") val planName: String,
    @ColumnInfo(name = "start_date") val startDate: Long,
    @ColumnInfo(name = "end_date") val endDate: Long,
    @ColumnInfo(name = "expected_return") val expectedReturn: Double,
    @ColumnInfo(name = "status") val status: String = "ACTIVE" // ACTIVE, COMPLETED, CANCELLED
)