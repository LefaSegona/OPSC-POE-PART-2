package com.example.pocket_ninja

import android.app.Application
import com.example.pocket_ninja.data.database.AppDatabase
import com.example.pocket_ninja.data.repository.BudgetRepository

class PocketNinjaDBApplication : Application() {
    // Database instance
    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }

    // Repository instance
    val budgetRepository: BudgetRepository by lazy {
        BudgetRepository(database.budgetDao())
    }

    companion object {
        private var instance: PocketNinjaDBApplication? = null
        fun getInstance() = instance ?:
        throw IllegalStateException("Application not initialized!")
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }
}