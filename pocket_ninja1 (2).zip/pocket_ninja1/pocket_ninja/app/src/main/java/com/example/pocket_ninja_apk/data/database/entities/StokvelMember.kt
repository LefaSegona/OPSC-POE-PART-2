package com.example.pocket_ninja.data.database.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey

@Entity(
    tableName = "stokvel_members",
    primaryKeys = ["group_id", "user_id"],
    foreignKeys = [
        ForeignKey(
            entity = StokvelGroup::class,
            parentColumns = ["group_id"],
            childColumns = ["group_id"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = User::class,
            parentColumns = ["user_id"],
            childColumns = ["user_id"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class StokvelMember(
    @ColumnInfo(name = "group_id") val groupId: Long,
    @ColumnInfo(name = "user_id") val userId: Long,
    @ColumnInfo(name = "joined_at") val joinedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "is_admin") val isAdmin: Boolean = false
)