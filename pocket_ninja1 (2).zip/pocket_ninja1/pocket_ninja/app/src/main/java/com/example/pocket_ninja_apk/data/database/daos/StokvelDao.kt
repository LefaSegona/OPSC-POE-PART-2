package com.example.pocket_ninja.data.database.daos

import androidx.room.*
import com.example.pocket_ninja.data.database.entities.StokvelGroup
import com.example.pocket_ninja.data.database.entities.StokvelMember

@Dao
interface StokvelDao {
    @Insert
    suspend fun createGroup(group: StokvelGroup): Long

    @Insert
    suspend fun addMember(member: StokvelMember)

    @Query("""
        UPDATE stokvel_groups 
        SET current_amount = current_amount + :amount 
        WHERE groupId = :groupId
    """)
    suspend fun contributeToGroup(
        groupId: Long,
        amount: Double
    )

    @Query("SELECT * FROM stokvel_groups WHERE groupId = :groupId")
    suspend fun getGroup(groupId: Long): StokvelGroup?

    @Query("""
        SELECT * FROM stokvel_members 
        WHERE groupId = :groupId 
        AND userId = :userId
    """)
    suspend fun getMember(groupId: Long, userId: Long): StokvelMember?

    @Query("DELETE FROM stokvel_members WHERE groupId = :groupId AND userId = :userId")
    suspend fun removeMember(groupId: Long, userId: Long)
}