package com.example.pocket_ninja

import android.app.Application
import com.example.pocket_ninja.data.database.AppDatabase

class PocketNinjaApplication : Application() {
    // Database instance accessible app-wide
    val database: AppDatabase by lazy {
        AppDatabase.getDatabase(this)
    }

    companion object {
        // Optional: quick access from anywhere
        lateinit var instance: PocketNinjaApplication
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }
}