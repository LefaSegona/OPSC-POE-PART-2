package com.example.pocket_ninja_apk

data class Expense_(val id:Int, val expenseDescription:String,
                    val category:String,
                    val expenseDate:String,
                    val expenseAmount:Double,
                    val expensePicture:ByteArray)
