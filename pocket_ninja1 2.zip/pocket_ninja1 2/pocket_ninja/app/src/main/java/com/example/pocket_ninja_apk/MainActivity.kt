package com.example.pocket_ninja_apk

import android.content.Intent
import android.os.Bundle
import android.os.PersistableBundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.pocket_ninja_apk.ui.theme.Pocket_ninja_apkTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.expenses)

            val btn_create_acc = findViewById<Button>(R.id.btn_To_create_acc)
            btn_create_acc.setOnClickListener{
                val intent = Intent(this, Create_account::class.java)
                startActivity(intent)

         //  val email = findViewById<TextView>(R.id.Login_Email)


        }
    }
}



