package com.example.pocket_ninja.data.database.daos

import androidx.room.*
import com.example.pocket_ninja.data.database.entities.Expense
import java.util.*

@Dao
interface ExpenseDao {
    @Insert
    suspend fun insert(expense: Expense): Long

    @Transaction
    @Query("""
        SELECT * FROM expenses 
        WHERE userId = :userId 
        AND date BETWEEN :startDate AND :endDate
        ORDER BY date DESC
    """)
    suspend fun getExpensesByDateRange(
        userId: Long,
        startDate: Date,
        endDate: Date
    ): List<Expense>

    @Query("""
        SELECT SUM(amount) FROM expenses 
        WHERE userId = :userId 
        AND categoryId = :categoryId
        AND date BETWEEN :startDate AND :endDate
    """)
    suspend fun getCategoryTotal(
        userId: Long,
        categoryId: Long,
        startDate: Date,
        endDate: Date
    ): Double?

    @Query("DELETE FROM expenses WHERE expenseId = :expenseId")
    suspend fun deleteById(expenseId: Long)

    @Update
    suspend fun update(expense: Expense)
}