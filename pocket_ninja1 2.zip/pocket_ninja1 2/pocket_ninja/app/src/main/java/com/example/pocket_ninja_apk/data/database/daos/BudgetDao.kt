package com.example.pocket_ninja.data.database.daos

import androidx.room.*
import com.example.pocket_ninja.data.database.entities.Budget

@Dao
interface BudgetDao {
    @Insert
    suspend fun insert(budget: Budget): Long

    @Query("""
        SELECT * FROM budgets 
        WHERE userId = :userId 
        AND month = :month 
        AND year = :year
    """)
    suspend fun getBudgetsForPeriod(
        userId: Long,
        month: Int,
        year: Int
    ): List<Budget>

    @Query("""
        UPDATE budgets 
        SET current_amount = current_amount + :amount 
        WHERE budgetId = :budgetId
    """)
    suspend fun incrementCurrentAmount(
        budgetId: Long,
        amount: Double
    )

    @Query("DELETE FROM budgets WHERE budgetId = :budgetId")
    suspend fun deleteById(budgetId: Long)
}