package com.example.pocket_ninja.data.database.daos

import androidx.room.*
import com.example.pocket_ninja.data.database.entities.Investment

@Dao
interface InvestmentDao {
    @Insert
    suspend fun create(investment: Investment): Long

    @Query("""
        UPDATE investments 
        SET status = :status,
            end_date = :endDate
        WHERE investmentId = :investmentId
    """)
    suspend fun completeInvestment(
        investmentId: Long,
        status: String,
        endDate: Long
    )

    @Query("SELECT * FROM investments WHERE userId = :userId ORDER BY start_date DESC")
    suspend fun getUserInvestments(userId: Long): List<Investment>

    @Query("SELECT * FROM investments WHERE investmentId = :investmentId")
    suspend fun getInvestment(investmentId: Long): Investment?

    @Query("DELETE FROM investments WHERE investmentId = :investmentId")
    suspend fun delete(investmentId: Long)
}