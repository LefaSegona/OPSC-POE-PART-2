package com.example.pocket_ninja.data.database.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "budgets")
data class Budget(
    @PrimaryKey(autoGenerate = true) val budgetId: Long = 0,
    @ColumnInfo(name = "user_id") val userId: Long,
    @ColumnInfo(name = "category_id") val categoryId: Long,
    @ColumnInfo(name = "month") val month: Int,
    @ColumnInfo(name = "year") val year: Int,
    @ColumnInfo(name = "min_amount") val minAmount: Double,
    @ColumnInfo(name = "max_amount") val maxAmount: Double,
    @ColumnInfo(name = "current_amount") val currentAmount: Double = 0.0
)