package com.example.pocket_ninja.data.database

import androidx.room.TypeConverter
import java.util.*

class Converters {
    // Date ↔ Long conversions
    @TypeConverter
    fun fromTimestamp(value: Long?): Date? {
        return value?.let { Date(it) }
    }

    @TypeConverter
    fun dateToTimestamp(date: Date?): Long? {
        return date?.time
    }

    // Add more converters as needed:
    /*
    @TypeConverter
    fun fromSomeType(value: SomeType): String {
        return value.toString()
    }

    @TypeConverter
    fun toSomeType(value: String): SomeType {
        return SomeType.parse(value)
    }
    */
}